# Victory Command

Victory Command is a WW2-themed base-building and strategy game inspired by classics like War2Victory/War2Glory.
Manage resources, fortify your cities, train armies, recruit officers, and push your influence across multiple theaters in PvE campaigns.

... (snipped for brevity)
